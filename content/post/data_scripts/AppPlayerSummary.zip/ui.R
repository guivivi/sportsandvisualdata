library(shinydashboard)  # 0.7.1 dashboardPage
library(shinycssloaders) # 0.2.0 withSpinner
dashboardPage(
  dashboardHeader(
    title = textOutput("title1")
    
  ),
  dashboardSidebar(
    radioButtons(inputId = "language", label = "",
                 choices = c("Espanol" = "es", "English" = "en"),
                 selected = "es"),
    
    sidebarMenu(
      uiOutput("compet"),
      uiOutput("typeSeason"),
      menuItem(textOutput("tab1"), tabName = "tab1", icon = icon("table")),
      menuItem(textOutput("info"), tabName = "info", icon = icon("info-circle"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "tab1",
              fluidRow(
                box(uiOutput("player"),
                    uiOutput("team_rival"), 
                    uiOutput("type_stats"),
                    width = 3),
                box(
                  span(textOutput("tab1_1_comment"), style = "color:blue;font-size:18px"),
                  br(),
                  # https://github.com/rstudio/DT/issues/34
                  div(withSpinner(DT::dataTableOutput("tab1_1")), style = "overflow-x: scroll"),
                  width = 9),
                box(
                  span(textOutput("tab1_2_comment"), style = "color:blue;font-size:18px"),
                  br(),
                  div(withSpinner(DT::dataTableOutput("tab1_2")), style = "font-size:80% ; overflow-x: scroll"),
                  width = 12), 
                box(
                  span(textOutput("tab1_3_comment"), style = "color:blue;font-size:18px"),
                  br(),
                  div(withSpinner(DT::dataTableOutput("tab1_3")), style = "font-size:80% ; overflow-x: scroll"),
                  
                  width = 12) 
              )
      ),
      tabItem(tabName = "info", 
              p("Guillermo Vinue"), 
              p("guillermovinue@gmail.com"),
              p(tags$b("INFO VARIABLES:")),
              p(align = "left", a("www.uv.es/vivigui/docs/buscador_datos_baloncesto.pdf", 
                                  href = "https://www.uv.es/vivigui/docs/buscador_datos_baloncesto.pdf", 
                                  target = "_blank"))
      )
    )
  ),
  title = "Buscador datos baloncesto"
)  