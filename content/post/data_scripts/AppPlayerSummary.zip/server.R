library(shiny)   # 1.2.0
library(BAwiR)   # 1.2
library(dplyr)   # 0.8.0
library(tidyr)   # 0.8.3
library(forcats) # 0.4.0 fct_collapse
library(DT)      # 0.7   dataTableOutput
library(countrycode) # 1.1.0 countrycode

options(warn = -1)
load("translation.bin") 
source("helpers.R")

shinyServer(function(input, output){
  tr <- function(text){ 
    sapply(text, function(s) translation[[s]][[input$language]], USE.NAMES = FALSE)
  } 

  output$title1 <- renderText({
    tr("title1")
  })
  
  output$progress <- renderText({
    tr("progress")
  })
  
  output$tab_comment <- renderText({
    tr("tab_comment")
  })
  
  tableData <- reactive({
    url <- "https://www.uv.es/vivigui/softw/data_app_euroacb.RData?raw=true"
    download.file(url, destfile = "data_app_euroacb.RData", mode = "wb") 
    load("data_app_euroacb.RData")
    inFile <<- data_app_euroacb
    return(list(inFile = inFile))
  })

  output$compet <- renderUI({
    inFile <- tableData()$inFile
    selectInput("compet", tr("Compet"), 
                unique(inFile$Compet), 
                selected = unique(inFile$Compet)[1])
  })
  
  output$typeSeason <- renderUI({
    inFile <- tableData()$inFile
    choi <- c(unique(inFile[inFile$Compet == input$compet, "Type_season"]))$Type_season
    
    if (input$language == "es") {
      choi[choi == "Regular Season"] <- "Temporada Regular"
      choi_def <- c(choi, "Todo")
    }else if (input$language == "en") {
      choi_def <- c(choi, "All")
    }
    
    selectInput("typeSeason", 
                tr("TypeSeas"), 
                choices = choi_def,
                selected = choi_def[1])
  })
  
  output$tab1 <- renderText({
    tr("tab1")
  })
  
  output$info <- renderText({
    tr("info")
  })
  
  output$type_stats <- renderUI({
    if (input$language == "en") {
      choices_lang <- c("Total", "Average")
    }else if (input$language == "es") {
      choices_lang <- c("Totales", "Promedio")
    }
    
    selectInput("type_stats", tr("Type_stats"), 
                choices = choices_lang,
                selected = choices_lang[1])
  })
  
  data_tab1 <- reactive({
    inFile <- tableData()$inFile
    
    if (input$language == "es") {
      inFile <- inFile %>%
        mutate(Position = plyr::mapvalues(Position, 
                                          from = c("Guard", "Forward", "Center"),
                                          to = c("Base", "Alero", "Pivot")))
    }
    
    if (is.null(input$compet)) {
      df1 <- inFile %>%
        filter(Compet == "ACB",
               Type_season == "Regular Season") 
      separ <- " - " # ACB.
      return(list(df1 = df1, separ = separ))
    }else{
      if (input$typeSeason %in% c("Regular Season", "Temporada Regular")) {
        type_se <- "Regular Season"
      }else{
        type_se <- input$typeSeason
      }
      df1 <- inFile %>%
        filter(Compet == input$compet,
               Type_season == type_se)
      
      if (input$compet == "ACB") {
        separ <- " - " # ACB.
      }else{
        separ <- "-"   # Euroleague and Eurocup. 
      }
      return(list(df1 = df1, separ = separ))
    }
  })
  
  output$player <- renderUI({
    names <- sort(unique(data_tab1()$df1$Player.x))
    names <- sort(as.character(names))
    
    selectInput(inputId = "player", 
                label = tr("Jugadores"),
                choices = names,
                selected = names[1],
                multiple = FALSE)
  })
  
  output$team_rival <- renderUI({
    df11 <- data_tab1()$df1 %>%
      rename(Team_player = Team) %>%
      separate(Game, c("Team1", "Team2"), sep = data_tab1()$separ, remove = FALSE) %>%
      rename(Team = Team1)
    # Recode first the home teams:
    if (is.null(input$compet)) {
      compet <- "ACB"
    }else{
      compet <- input$compet
    }
    df12 <- do_recode_teams(compet, df11) %>%
      rename(Team1 = Team,
             Team = Team2)
    # Recode then the visitor teams:
    df13 <- do_recode_teams(compet, df12) %>%
      rename(Team2 = Team)
    
    if (is.null(input$player)) {
      rivals <- ""
    }else{
      df2 <- df13 %>% 
        filter(Player.x == input$player)
      
      rivals <- sort(unique(c(as.character(unique(df2$Team1)), 
                              as.character(unique(df2$Team2)))))
    }  
    
    selectInput(inputId = "team_rival", 
                label = tr("Rivales"),
                choices = rivals,
                selected = rivals[1],
                multiple = FALSE)
  })
  
  output$tab1_1_comment <- renderText({
    tr("tab1_1_comment")
  })
  
  output$tab1_1 <- renderDataTable({ 
    df11 <- data_tab1()$df1 %>%
      rename(Team_player = Team) %>%
      separate(Game, c("Team1", "Team2"), sep = data_tab1()$separ, remove = FALSE) %>%
      rename(Team = Team1)
    # Recode first the home teams:
    if (is.null(input$compet)) {
      compet <- "ACB"
    }else{
      compet <- input$compet
    }
    df12 <- do_recode_teams(compet, df11) %>%
      rename(Team1 = Team,
             Team = Team2)
    # Recode then the visitor teams:
    df13 <- do_recode_teams(compet, df12) %>%
      rename(Team2 = Team)
    
    if (is.null(input$player)) {
      df3 <- NULL
    }else{
      df2 <- df13 %>% 
        filter(Player.x == input$player)
      
      df3 <- df2 %>%
        distinct(Player.x, Position, Height, Date_birth, Nationality, Website_player) %>%
        rename(Player = Player.x)
      
      if (nrow(df3) > 0) {
        if (input$compet == "ACB") {
          df3$Website_player <- paste0("<a href=\"", df3$Website_player, 
                                       "\" target=\"_blank\">", 
                                       gsub("http://www.acb.com/", "", df3$Website_player), "</a>")   
        }else if (input$compet == "Euroleague") {
          df3$Website_player <- paste0("<a href=\"", df3$Website_player, 
                                       "\" target=\"_blank\">", 
                                       gsub("http://www.euroleague.net/", "", df3$Website_player), 
                                       "</a>")   
        }else if (input$compet == "Eurocup") {
          df3$Website_player <- paste0("<a href=\"", df3$Website_player, 
                                       "\" target=\"_blank\">", 
                                       gsub("http://www.eurocupbasketball.com/eurocup/", "", 
                                            df3$Website_player), "</a>")   
        }
      }
      
      if (input$language == "es") {
        colnames(df3) <- c("Nombre", "Posicion", "Altura", "Fecha de nacimiento", 
                           "Nacionalidad", "Web_jugador")
        df3$Nacionalidad <- countrycode(df3$Nacionalidad, "country.name.en", "un.name.es")
      }
    }
    return(df3)
  }, escape = FALSE) # escape = FALSE so that the link in website_player works.
  
  output$tab1_2_comment <- renderText({
    tr("tab1_2_comment")
  })
  
  output$tab1_2 <- renderDataTable({ 
    df11 <- data_tab1()$df1 %>%
      rename(Team_player = Team) %>%
      separate(Game, c("Team1", "Team2"), sep = data_tab1()$separ, remove = FALSE) %>%
      rename(Team = Team1)
    # Recode first the home teams:
    if (is.null(input$compet)) {
      compet <- "ACB"
    }else{
      compet <- input$compet
    }
    df12 <- do_recode_teams(compet, df11) %>%
      rename(Team1 = Team,
             Team = Team2)
    # Recode then the visitor teams:
    df13 <- do_recode_teams(compet, df12) %>%
      rename(Team2 = Team)
    
    if (is.null(input$player)) {
      df8 <- NULL
    }else{
      df2 <- df13 %>% 
        filter(Player.x == input$player)
      
      if (is.null(input$team_rival)) {
        df8 <- NULL
      }else{
        df4 <- df2 %>%
          filter(Team_player != input$team_rival) %>%
          filter(Team1 == input$team_rival | Team2 == input$team_rival) %>%
          mutate(Game1 = paste(Team1, "-", Team2, sep = "")) %>%
          select(-Game) %>%
          rename(Game = Game1)
        
        if (nrow(df4) > 0) {
          df6 <- do_add_adv_stats(df4) %>%
            rename(Team = Team_player) %>%
            select(-Team1, -Team2)
          
          if (input$typeSeason %in% c("Regular Season", "Temporada Regular")) {
            type_se <- "Regular Season"
          }else{
            type_se <- input$typeSeason
          }
          
          df7 <- do_stats(df6, input$type_stats, "", input$compet, type_se) %>% 
            # season = "" to avoid naming the column of seasons.
            ungroup() %>%
            select(-c(CombinID, Position, Nationality, Compet, EPS, Season))
          
          df8 <- df7 %>%
            unite(Twos, TwoP, TwoPA, sep = "/") %>%
            unite(Threes, ThreeP, ThreePA, sep = "/") %>%
            unite(FT, FT, FTA, sep = "/") %>%
            mutate(TRB1 = paste(TRB, " (", DRB, "+", ORB, ")", sep = "")) %>%
            select(-c(TwoPPerc, ThreePPerc, FTPerc, TRB, DRB, ORB, Type_season)) %>%
            rename(TRB = TRB1, "+/-" = PlusMinus) %>%
            select(-c(Name, GS, FG, FGA, FGPerc, GameSc, PIE, EFGPerc, ThreeRate,  
                      FRate, STL_TOV, AST_TOV, PPS, OE)) %>%
            select(1:7, TRB, everything())
          
          df8 <- df8 %>% select(-Counteratt)
          
          if (input$language == "es") {
            colnames(df8) <- c("Equipo", "PJ", "Min", "PTS", "T2", "T3", "TL", 
                              "RT", "AST", "Rob", "Perd", "Tap", "TapR", 
                              "Mates", "FP", "FPR", "+/-", "Valor", "Tipo_estad")
          }else{
            colnames(df8) <- c("Team", "GP", "MP", "PTS", "Twos", "Threes", "FT", 
                              "TRB", "AST", "STL", "TOV", "BLKfv", "BLKag", 
                              "Dunks", "PF", "PFrv", "+/-", "PIR", "Type_stat")
          }
                  
        }else{
          df8 <- NULL
        }
      }
    }  
  
    if (is.null(df8)) {
      df8 <- as.data.frame(tr("tab_comment"))
      colnames(df8) <- NULL
    }
  
  return(df8)
  })
  
  output$tab1_3_comment <- renderText({
    tr("tab1_3_comment")
  })
  
  output$tab1_3 <- renderDataTable({ 
    df11 <- data_tab1()$df1 %>%
      rename(Team_player = Team) %>%
      separate(Game, c("Team1", "Team2"), sep = data_tab1()$separ, remove = FALSE) %>%
      rename(Team = Team1)
    # Recode first the home teams:
    if (is.null(input$compet)) {
      compet <- "ACB"
    }else{
      compet <- input$compet
    }
    df12 <- do_recode_teams(compet, df11) %>%
      rename(Team1 = Team,
             Team = Team2)
    # Recode then the visitor teams:
    df13 <- do_recode_teams(compet, df12) %>%
      rename(Team2 = Team)
    
    if (is.null(input$player)) {
      df51 <- NULL
    }else{
      df2 <- df13 %>% 
        filter(Player.x == input$player)
      
      if (is.null(input$team_rival)) {
        df51 <- NULL
      }else{
        df4 <- df2 %>%
          filter(Team_player != input$team_rival) %>%
          filter(Team1 == input$team_rival | Team2 == input$team_rival) %>%
          mutate(Game1 = paste(Team1, "-", Team2, sep = "")) %>%
          select(-Game) %>%
          rename(Game = Game1)
        
        df5 <- df4 %>%
          select(-c(GS, Player.x, Number, Day, Team1, Team2, Team_player, GameID, CombinID, Player.y, 
                    Position, Height, Date_birth, Nationality, Website_player, Month, Compet,
                    Date, Age)) %>%
          rename(Result = GameRes, "+/-" = PlusMinus) %>%
          select(Game, Result, everything())
        
        if (nrow(df5) > 0) {
          df51 <- df5 %>%
            unite(Twos, TwoP, TwoPA, sep = "/") %>%
            unite(Threes, ThreeP, ThreePA, sep = "/") %>%
            unite(FT, FT, FTA, sep = "/") %>%
            mutate(Season1 = paste(Season, " (", Type_season, ")", sep = "")) %>%
            mutate(TRB1 = paste(TRB, " (", DRB, "+", ORB, ")", sep = "")) %>%
            select(-c(TwoPPerc, ThreePPerc, FTPerc, TRB, DRB, ORB, Season, Type_season)) %>%
            rename(TRB = TRB1, Season = Season1) %>%
            select(1:7, TRB, everything()) %>%
            mutate(Game1 = paste(Game, " (", Result, ")", sep = "")) %>%
            select(-Game, -Result) %>%
            rename(Game = Game1) %>%
            select(Game, everything())
          
          colnames(df51)[4:6] <- c("T2", "T3", "TL")
         
          if (input$compet == "ACB") {
            df51$Website <- paste0("<a href=\"", df51$Website, 
                                   "\" target=\"_blank\">", 
                                   gsub("http://www.acb.com/", "", df51$Website), "</a>")   
          }else if (input$compet == "Euroleague") {
            df51$Website <- paste0("<a href=\"", df51$Website, 
                                   "\" target=\"_blank\">", 
                                   gsub("http://www.euroleague.net/", "", df51$Website), "</a>")   
          }else if (input$compet == "Eurocup") {
            df51$Website <- paste0("<a href=\"", df51$Website, 
                                         "\" target=\"_blank\">", 
                                         gsub("http://www.eurocupbasketball.com/eurocup/", "", 
                                              df51$Website), "</a>")   
          }
           
          df51 <- df51 %>% 
            mutate(Game = paste(Game, Website, sep = "\n")) %>%
            select(-Website, -Counteratt)
                    
          if (input$language == "es") {
            colnames(df51) <- c("Partido", "Min", "PTS", "T2", "T3", "TL", 
                               "RT", "AST", "Rob", "Perd", "Tap", "TapR", 
                               "Mates", "FP", "FPR", "+/-", "Valor", "Temp")
          }else{
            colnames(df51) <- c("Game", "MP", "PTS", "Twos", "Threes", "FT", 
                               "TRB", "AST", "STL", "TOV", "BLKfv", "BLKag", 
                               "Dunks", "PF", "PFrv", "+/-", "PIR", "Season")
          }
          
        }else{
          df51 <- NULL
        }
      }
    }  
    
    if (is.null(df51)) {
      df51 <- as.data.frame(tr("tab_comment"))
      colnames(df51) <- NULL
    }
    
    return(df51)
  }, escape = FALSE)
  
})
