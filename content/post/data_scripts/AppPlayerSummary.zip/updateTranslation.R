library(plyr)
# Set working directory to source file location.
translationContent <- read.delim("dictionary_app_bkball.csv", header = TRUE, sep = ",", as.is = TRUE) 
translation <- dlply(translationContent ,.(key), function(s) key = as.list(s))
save(translation, file = "translation.bin")
